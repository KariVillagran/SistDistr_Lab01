# SistDistr_Lab01
Laboratorio 01 del Ramo Sistemas Distribuidos (Usach Vespertino)

Proyecto para probar la arquitectura Cliente-Servidor, para esto se utiliza Java-RMI para realizar dicha tarea.
La base de datos a utilizar será Postgresql.
